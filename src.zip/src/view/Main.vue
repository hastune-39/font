<template>
  <my-home-pagelist/>
</template>

<script>
  import myHomePagelist from '../components/picturelist/HomePagelist'

  export default {
    components: {
      myHomePagelist
    },
  }
</script>

<style scoped>


</style>
