<template>
  <my-home-pagelist/>
</template>

<script>
  import myHomePagelist from '../components/picturelist/PictureList'

  export default {
    components: {
      myHomePagelist
    },
  }
</script>

<style scoped>


</style>
