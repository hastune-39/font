<template>

</template>

<script>
    export default {
        name: "PainterSideBar"
    }
</script>

<style scoped>

</style>
